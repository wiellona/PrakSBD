const db = require("../database/pg.database");

exports.createTransaction = async (user_id, item_id, quantity, total) => {
  try {
    const query = `
        INSERT INTO transactions (user_id, item_id, quantity, total, status, created_at) 
        VALUES ($1, $2, $3, $4, 'pending', NOW()) 
        RETURNING *`;
    const result = await db.query(query, [user_id, item_id, quantity, total]);
    return result.rows[0];
  } catch (error) {
    console.error("Error creating transaction:", error.message);
    return null;
  }
};

exports.getTransactionById = async (id) => {
  const query = `SELECT * FROM transactions WHERE id = $1`;
  const result = await pool.query(query, [id]);
  return result.rows[0];
};

exports.payTransaction = async (id) => {
  const query = `UPDATE transactions SET status = 'paid' WHERE id = $1 RETURNING *`;
  const result = await pool.query(query, [id]);
  return result.rows[0];
};

exports.deleteTransaction = async (id) => {
  const query = `DELETE FROM transactions WHERE id = $1 RETURNING *`;
  const result = await pool.query(query, [id]);
  return result.rows[0];
};
