const db = require("../database/pg.database");
const baseResponse = require("../util/baseResponse.util");

exports.createTransaction = async (req, res) => {
  try {
    const { item_id, user_id, quantity } = req.body;

    // Validasi input
    if (!item_id || !user_id || quantity <= 0) {
      return baseResponse(res, false, 400, "Invalid input", null);
    }

    // Cek apakah item tersedia
    const itemResult = await db.query("SELECT * FROM items WHERE id = $1", [
      item_id,
    ]);
    if (itemResult.rows.length === 0) {
      return baseResponse(res, false, 404, "Item not found", null);
    }
    const item = itemResult.rows[0];

    // Cek apakah user tersedia
    const userResult = await db.query("SELECT * FROM users WHERE id = $1", [
      user_id,
    ]);
    if (userResult.rows.length === 0) {
      return baseResponse(res, false, 404, "User not found", null);
    }

    // Hitung total harga transaksi
    const total = item.price * quantity;

    // Simpan transaksi ke database
    const transactionResult = await db.query(
      "INSERT INTO transactions (user_id, item_id, quantity, total, status, created_at) VALUES ($1, $2, $3, $4, $5, NOW()) RETURNING *",
      [user_id, item_id, quantity, total, "pending"]
    );

    return baseResponse(
      res,
      true,
      201,
      "Transaction created",
      transactionResult.rows[0]
    );
  } catch (error) {
    console.error("Error creating transaction:", error);
    return baseResponse(res, false, 500, "Internal Server Error", null);
  }
};

exports.payTransaction = async (req, res) => {
  try {
    const { id } = req.params;

    // Cek apakah transaksi ada
    const transaction = await transRepository.getTransactionById(id);
    if (!transaction) {
      return res
        .status(404)
        .json(baseResponse(false, "Transaction not found", null));
    }

    if (transaction.status === "paid") {
      return res
        .status(400)
        .json(baseResponse(false, "Transaction already paid", null));
    }

    // Ambil data user dan item terkait
    const user = await userRepository.getUserById(transaction.user_id);
    const item = await itemRepository.getItemById(transaction.item_id);

    if (!user || !item) {
      return res
        .status(404)
        .json(baseResponse(false, "User or item not found", null));
    }

    // Pastikan user memiliki saldo yang cukup
    if (user.balance < transaction.total) {
      return res
        .status(400)
        .json(baseResponse(false, "Insufficient balance", null));
    }

    // Pastikan stok item cukup
    if (item.stock < transaction.quantity) {
      return res
        .status(400)
        .json(baseResponse(false, "Insufficient stock", null));
    }

    // Kurangi saldo user dan stok item
    await userRepository.updateBalance(
      user.id,
      user.balance - transaction.total
    );
    await itemRepository.updateStock(
      item.id,
      item.stock - transaction.quantity
    );

    // Update status transaksi menjadi "paid"
    const updatedTransaction = await transRepository.payTransaction(id);

    res.json(baseResponse(true, "Payment successful", updatedTransaction));
  } catch (error) {
    console.error("Error in payTransaction:", error.message);
    res.status(500).json(baseResponse(false, "Failed to pay", null));
  }
};

exports.deleteTransaction = async (req, res) => {
  try {
    const { id } = req.params;

    // Cek apakah transaksi ada
    const transaction = await transRepository.getTransactionById(id);
    if (!transaction) {
      return res
        .status(404)
        .json(baseResponse(false, "Transaction not found", null));
    }

    // Hapus transaksi
    const deletedTransaction = await transRepository.deleteTransaction(id);
    res.json(baseResponse(true, "Transaction deleted", deletedTransaction));
  } catch (error) {
    console.error("Error in deleteTransaction:", error.message);
    res
      .status(500)
      .json(baseResponse(false, "Failed to delete transaction", null));
  }
};
